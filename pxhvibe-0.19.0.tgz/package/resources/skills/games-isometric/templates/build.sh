npx vite build
